export { AdminPage } from "./AdminPage";
